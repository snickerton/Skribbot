// ==UserScript==
// @name     skribbleTest
// @version  1
// @require  http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js
// @grant    GM_setClipboard
// ==/UserScript==



function KeyCheck(e)
{
   //alert(e.keyCode);

 if(e.keyCode == 17){
 	var currWord = document.getElementById('currentWord').textContent;
	alert(currWord);
  GM.setClipboard(currWord);
 }
}

window.addEventListener('keydown', KeyCheck, true);